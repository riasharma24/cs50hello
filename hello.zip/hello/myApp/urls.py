from . import views
from django.urls import path

urlpatterns=[
    path('brian',views.brian, name='brain'),
    path('<str:user>', views.greet, name='greet'),
    path('', views.index, name='index')
]