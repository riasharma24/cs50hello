from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.


def brian(request):
    return HttpResponse('Hello Brian, this is my app!')

def greet(request, user):
    return render(request, 'myApp/greet.html',{
        'user':user.capitalize()
    })

def index(request):
    return HttpResponse('Hello')