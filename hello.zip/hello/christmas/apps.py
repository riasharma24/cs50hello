from django.apps import AppConfig


class ChristmasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'christmas'
