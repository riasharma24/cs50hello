from django.shortcuts import render
import datetime
# Create your views here.

now=datetime.datetime.now()

def index(request):
    return render(request,'christmas/index.html',{
        'christmas': now.month==12 and now.day==25
    })