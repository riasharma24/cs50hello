from django.shortcuts import render

# Create your views here.

tasks=[]

def index(request):
    return render(request,'tasks/index.html',{
        'tasks':tasks
    })

def add(request):
    return render(request, 'tasks/add.html')

def add_task(request):
    if request.method=='POST':
        task=request.POST['q']
        tasks.append(task)
        return render(request,'tasks/index.html',{
            'tasks':tasks
        })